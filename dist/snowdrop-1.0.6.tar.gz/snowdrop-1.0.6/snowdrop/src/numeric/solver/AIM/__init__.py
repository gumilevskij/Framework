__all__ = ["Aimerr","AIMsolver","Amalg","buildA",
           "checkA","copyW","Eigensystem","makeF",
           "makePhi","makeVartheta","Obstruct","reducedForm"]